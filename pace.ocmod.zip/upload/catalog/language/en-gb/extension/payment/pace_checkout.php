<?php
// Text
$_['text_title']               = 'Pace checkout';
$_['create_transaction_error'] = 'Your transaction could not be created on Pace. Please contact our team at support@pacenow.co. code: %s';